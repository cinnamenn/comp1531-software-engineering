```javascript
let data = {
  users: [
    {
      uId: 1,
      nameFirst: 'Peter',
      nameLast: 'File',
      email: 'p.file@email.com', 
    },
  ],

  channels: [
    {
      channelId: 1,
      name: "Peter's Channel",
    },
  ],
};
```
[Optional] short description: 
